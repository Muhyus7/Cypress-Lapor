const { defineConfig } = require("cypress");

module.exports = defineConfig({
  screenshotOnRunFailure: true,
  screenshots: {
    enabled: true,
    on: 'failure',
    path: 'cypress/screenshots',
    capture: 'fullPage',
  },
  e2e: {
    setupNodeEvents(on, config) {
      on('after:screenshot', (details) => {
        console.log('Screenshot taken:', details.path);
        return null;
      });
    },
  },
});