/// <reference types="cypress"/>
import loginPage from "../../../pom/Lapor/Login/login";

describe('Login Feature', () => {

    let credentials;

    beforeEach(() => {
        cy.fixture('credentials.json').then((data) => {
            credentials = data;
        });

        cy.visit('https://lapor.folkatech.com/');
        loginPage.textSignIn().should('have.text', 'Sign In');
    });

    it('User Login with Valid credentials', () => {
        loginPage.inputUsername().type(credentials.validUser.username);
        loginPage.inputPassword().type(credentials.validUser.password);
        loginPage.buttonSignIn().click();
        loginPage.menuDashboard().should('have.text', 'Dashboard');
    });

    it('User Login with Invalid username', () => {
        loginPage.inputUsername().type(credentials.invalidUser.username);
        loginPage.inputPassword().type(credentials.invalidUser.password);
        loginPage.buttonSignIn().click();
        loginPage.errorMessage().should('have.text', 'Login Gagal! Akun tidak ada.');
    });

    it('User Login with Invalid password', () => {
        loginPage.inputUsername().type(credentials.invalidPasswordUser.username);
        loginPage.inputPassword().type(credentials.invalidPasswordUser.password);
        loginPage.buttonSignIn().click();
        loginPage.errorMessage().should('have.text', 'Login Gagal! Kata sandi salah.');
    });

});
