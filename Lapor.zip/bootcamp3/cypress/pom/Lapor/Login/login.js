export default class loginPage {
    static textSignIn(){
        return cy.get('[class="font-weight-bolder text-info text-gradient"]');
    }

    static inputUsername(){
        return cy.get('[name="email"]');
    }

    static inputPassword(){
        return cy.get('[id="password"]');
    }
    
    static buttonSignIn(){
        return cy.get('[class="btn bg-gradient-info w-100 mt-4 mb-0"]')
    }
    static menuDashboard(){
        return cy.get('[class="mb-3"]')
    }
    static errorMessage(){
        return cy.get('[role="alert"]')
    }
}